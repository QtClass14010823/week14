#include "MainWindow.h"

#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
{

    layout = new QVBoxLayout(this);
    btnVar = new QPushButton("Variables", this);
    btnBadMath = new QPushButton("Bad Math", this);
    btnCusDbg = new QPushButton("Custom Debug", this);
    btnBadPtr = new QPushButton("Bad Pointer", this);

    btnVar->setObjectName(QString::fromUtf8("btnVar"));
    btnBadMath->setObjectName(QString::fromUtf8("btnBadMath"));
    btnCusDbg->setObjectName(QString::fromUtf8("btnCusDbg"));
    btnBadPtr->setObjectName(QString::fromUtf8("btnBadPtr"));

    layout->addWidget(btnVar);
    layout->addWidget(btnBadMath);
    layout->addWidget(btnCusDbg);
    layout->addWidget(btnBadPtr);

    QMetaObject::connectSlotsByName(this);
}

MainWindow::~MainWindow()
{
}

void MainWindow::on_btnVar_clicked()
{
    myCls.variables();
}

void MainWindow::on_btnBadMath_clicked()
{
    myCls.badMath();
}

void MainWindow::on_btnCusDbg_clicked()
{
    myCls.customDebug();
}

void MainWindow::on_btnBadPtr_clicked()
{
    QString *strPtr = myCls.badPointer();

    // The program has unexpectedly finished.
    qDebug() << *strPtr;
}
