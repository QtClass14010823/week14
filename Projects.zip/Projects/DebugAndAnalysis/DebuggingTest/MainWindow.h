#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>

#include "MyClass.h"

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void on_btnVar_clicked();
    void on_btnBadMath_clicked();
    void on_btnCusDbg_clicked();
    void on_btnBadPtr_clicked();

private:
    QVBoxLayout *layout;
    QPushButton *btnVar, *btnBadMath, *btnCusDbg, *btnBadPtr;

    MyClass myCls;
};

#endif // MAINWINDOW_H
