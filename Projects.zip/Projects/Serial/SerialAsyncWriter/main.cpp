#include <iostream>

#include <QCoreApplication>

#include "Global.h"
#include "SerialPortWriter.h"

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    SerialPortWriter serialPort;
    char hexBuff[100], binBuff[100];

    cout << "Enter hex code to send (Sample: FF1e0A): ";
    cin >> hexBuff;

    hex2bin(hexBuff, binBuff);
    serialPort.write(binBuff);

    return a.exec();
}
