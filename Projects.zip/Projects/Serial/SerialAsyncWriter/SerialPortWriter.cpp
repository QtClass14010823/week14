#include "SerialPortWriter.h"

#include <iostream>

#include <QCoreApplication>

#include "Global.h"

using namespace std;

SerialPortWriter::SerialPortWriter(QObject *parent) : QObject(parent)
{
    m_byteWritten = 0;

    m_serial.setPortName("COM4");
    m_serial.setBaudRate(QSerialPort::Baud9600);
    m_serial.setDataBits(QSerialPort::Data8);
    m_serial.setParity(QSerialPort::NoParity);
    m_serial.setStopBits(QSerialPort::OneStop);
    m_serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!m_serial.open(QIODevice::WriteOnly))
    {
        cout << "Failed to open port." << endl;
        cout << "Error: " << m_serial.errorString().toStdString().c_str() << endl;
    }

    connect(&m_serial, &QSerialPort::bytesWritten, this, &SerialPortWriter::handleBytesWritten);
    connect(&m_serial, &QSerialPort::errorOccurred, this, &SerialPortWriter::handleError);
}

SerialPortWriter::~SerialPortWriter()
{
    if (m_serial.isOpen())
    {
        m_serial.close();
    }
}

void SerialPortWriter::write(const QByteArray &data)
{
    m_writeData = data;
    const quint64 bytesWritten = m_serial.write(data);

    if (bytesWritten == -1)
    {
        cout << "Failed to write the data to port." << endl;
    }
    else if (bytesWritten != data.size())
    {
        cout << "Failed to write all the data to port." << endl;
    }
}

void SerialPortWriter::handleBytesWritten(quint64 bytes)
{
    m_byteWritten += bytes;

    if (m_byteWritten == m_writeData.size())
    {
        m_byteWritten = 0;
        cout << "Data successfully sent." << endl;
    }

    char hexBuff[100], binBuff[100];

    cout << "Enter hex code to send (Sample: FF1e0A): ";
    cin >> hexBuff;

    if (strlen(hexBuff) == 1 && hexBuff[0] == '0')
        QCoreApplication::quit();

    hex2bin(hexBuff, binBuff);
    write(binBuff);
}

void SerialPortWriter::handleError(QSerialPort::SerialPortError serialPortError)
{
    if (serialPortError == QSerialPort::WriteError)
    {
        cout << "An I/O error occured while writing the data." << endl;
        cout << "Error: " << m_serial.errorString().toStdString().c_str() << endl;
    }
    else
    {
        cout << "Error: " << m_serial.errorString().toStdString().c_str() << endl;
    }
}
