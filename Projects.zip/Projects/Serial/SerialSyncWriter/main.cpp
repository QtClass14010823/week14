#include <QCoreApplication>
#include <QSerialPort>

#include <iostream>

#include "Global.h"

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QSerialPort serial;

    serial.setPortName("COM4");
    serial.setBaudRate(QSerialPort::Baud9600);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!serial.open(QIODevice::WriteOnly))
    {
        cout << "Failed to open port." << endl;
        cout << "Error: " << serial.errorString().toStdString().c_str() << endl;
        return 1;
    }

    char hexBuff[100], binBuff[100];
    quint64 bytesWritten;

    while (true)
    {
        cout << "Enter hex code to send (Sample: FF1e0A): ";
        cin >> hexBuff;

        if (strlen(hexBuff) == 1 && hexBuff[0] == '0')
            return 0;

        hex2bin(hexBuff, binBuff);
        bytesWritten = serial.write(binBuff);

        if (bytesWritten == -1)
        {
            cout << "Failed to write the data to port." << endl;
        }
        else if (bytesWritten != QByteArray(binBuff).size())
        {
            cout << "Failed to write all the data to port." << endl;
        }
        else if (!serial.waitForBytesWritten(5000))
        {
            cout << "Operation timed out or an error occured." << endl;
            cout << "Error: " << serial.errorString().toStdString().c_str() << endl;
        }
        else
        {
            cout << "Data successfully sent." << endl;
        }
    }

    return 0;
}
