#ifndef SERIALPORTREADER_H
#define SERIALPORTREADER_H

#include <QObject>
#include <QSerialPort>

class SerialPortReader : public QObject
{
    Q_OBJECT
public:
    explicit SerialPortReader(QObject *parent = 0);
    ~SerialPortReader();

signals:

public slots:

private slots:
    void handleReadyRead();
    void handleError(QSerialPort::SerialPortError serialPortError);

private:
    QSerialPort m_serial;
};

#endif // SERIALPORTREADER_H
