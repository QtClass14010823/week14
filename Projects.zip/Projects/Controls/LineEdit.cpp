#include <QApplication>
#include <QLineEdit>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QLineEdit lineEdit;
    lineEdit.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QWidget>
#include <QLineEdit>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QLineEdit lineEdit(&widget);
    widget.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QWidget>
#include <QLineEdit>

QWidget *mainWidget = nullptr;

void OnTextChanged(const QString &text)
{
    if (mainWidget != nullptr)
    {
        mainWidget->setWindowTitle(text);
    }
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QLineEdit lineEdit(&widget);

    mainWidget = &widget;
    QObject::connect(&lineEdit, &QLineEdit::textChanged, OnTextChanged);

    widget.show();

    return a.exec();
}
