#include <QApplication>
#include <QPushButton>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QPushButton button("Exit");
    button.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QPushButton>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QPushButton button("Exit");
    button.show();

    QObject::connect(&button, &QPushButton::clicked, &a, &QApplication::quit);

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QPushButton>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QPushButton button("Exit", &widget);
    widget.show();

    QObject::connect(&button, &QPushButton::clicked, &a, &QApplication::quit);

    return a.exec();
}