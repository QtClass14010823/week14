#include "Notepad.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Notepad editor;
    editor.show();

    return a.exec();
}
