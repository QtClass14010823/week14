#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QFuture>
#include <QFutureWatcher>

#include "MyThread.h"

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtnStartClicked();

private:
    QGridLayout *layout;
    QPushButton *btnStart;
    QMutex mutex;
    MyThread thread1, thread2, thread3;
};

#endif // FORM_H
