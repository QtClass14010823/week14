#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>
#include <QString>
#include <QMutex>

class MyThread : public QThread
{
    Q_OBJECT

public:
    // constructor
    // set name and Stop is set as false by default
    MyThread(QString s, QMutex *mtx, QObject *parent = nullptr);

    // overriding the QThread's run() method
    void run();

private:
    QString name;
    QMutex *mutex;
};

#endif // MYTHREAD_H
