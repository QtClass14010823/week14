#include "Producer.h"

#include "Common.h"

Producer::Producer(QObject *parent) :
    QThread(parent)
{
}

void Producer::run()
{
    for (int i = 0; i < DataSize; ++i)
    {
        freeBytes.acquire();
        buffer[i % BufferSize] = i % 26 + 65;
        usedBytes.release();

        emit bufferFillCountChanged(usedBytes.available());
        emit producerCountChanged(i);
    }

    int i = 0;
}
