#include "Producer.h"

#include "Common.h"

Producer::Producer(QObject *parent) :
    QThread(parent)
{
}

void Producer::run()
{
	for (int i = 0; i < DataSize; ++i)
	{
		{
			const QMutexLocker locker(&mutex);

			while (numUsedBytes == BufferSize)
				bufferNotFull.wait(&mutex);
		}

        buffer[i % BufferSize] = i % 26 + 65;
		
		{
			const QMutexLocker locker(&mutex);
			++numUsedBytes;
			bufferNotEmpty.wakeAll();
		}

        emit bufferFillCountChanged(numUsedBytes);
        emit producerCountChanged(i);
    }
}
