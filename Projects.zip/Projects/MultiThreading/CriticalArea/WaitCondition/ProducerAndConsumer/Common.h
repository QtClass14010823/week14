#ifndef COMMON_H
#define COMMON_H

#include <QMutex>
#include <QWaitCondition>

extern const int DataSize;

extern const int BufferSize;
extern char buffer[];
extern int numUsedBytes;

extern QMutex mutex; // protects the buffer and the counter
extern QWaitCondition bufferNotEmpty;
extern QWaitCondition bufferNotFull;

#endif // COMMON_H
