#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>

#include "MyTask.h"

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtnClicked();

private:
    MyTask *task;
    QHBoxLayout *layout;
    QPushButton *btn;
};

#endif // FORM_H
