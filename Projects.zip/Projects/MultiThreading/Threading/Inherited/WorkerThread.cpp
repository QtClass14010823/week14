#include "WorkerThread.h"

#include <QDebug>

void WorkerThread::run()
{
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10; i++)
    {
        qDebug() << i;

        QThread::sleep(1);
    }
}
