#include "Form.h"

#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f),
    process(this)
{
    int index = 0;

    layout = new QGridLayout(this);
    lblExecutableTitle = new QLabel("Executable Path:", this);
    lblExecutablePath = new QLabel("", this);
    btnExecutablePath = new QPushButton("...", this);
    lblParam1 = new QLabel("Parameter 1:", this);
    editParam1 = new QLineEdit(this);
    lblParam2 = new QLabel("Parameter 2:", this);
    editParam2 = new QLineEdit(this);
    btnRunProc1 = new QPushButton("Run Process (Normal)", this);
    btnRunProc2 = new QPushButton("Run Process (Sync)", this);
    btnRunProc3 = new QPushButton("Run Process (Async)", this);
    btnRunProc4 = new QPushButton("Run Process (Stream)", this);
    btnRunProc5 = new QPushButton("Run Process (with Enviroment)", this);
    btnRunProc6 = new QPushButton("Run Process (Pipe Mode)", this);

    layout->addWidget(lblExecutableTitle, index, 0);
    layout->addWidget(lblExecutablePath, index, 1);
    layout->addWidget(btnExecutablePath, index, 2);
    index++;
    layout->addWidget(lblParam1, index, 0);
    layout->addWidget(editParam1, index, 1);
    index++;
    layout->addWidget(lblParam2, index, 0);
    layout->addWidget(editParam2, index, 1);
    index++;
    layout->addWidget(btnRunProc1, index, 0, 1, 3);
    index++;
    layout->addWidget(btnRunProc2, index, 0, 1, 3);
    index++;
    layout->addWidget(btnRunProc3, index, 0, 1, 3);
    index++;
    layout->addWidget(btnRunProc4, index, 0, 1, 3);
    index++;
    layout->addWidget(btnRunProc5, index, 0, 1, 3);
    index++;
    layout->addWidget(btnRunProc6, index, 0, 1, 3);

    this->setLayout(layout);

    connect(btnExecutablePath, &QPushButton::clicked, this, &Form::on_BtnExecutablePath_Clicked);
    connect(btnRunProc1, &QPushButton::clicked, this, &Form::on_BtnRunProc1_Clicked);
    connect(btnRunProc2, &QPushButton::clicked, this, &Form::on_BtnRunProc2_Clicked);
    connect(btnRunProc3, &QPushButton::clicked, this, &Form::on_BtnRunProc3_Clicked);
    connect(btnRunProc4, &QPushButton::clicked, this, &Form::on_BtnRunProc4_Clicked);
    connect(btnRunProc5, &QPushButton::clicked, this, &Form::on_BtnRunProc5_Clicked);
    connect(btnRunProc6, &QPushButton::clicked, this, &Form::on_BtnRunProc6_Clicked);
    // Note: Signal finished is overloaded in this class. To connect to this one using the function pointer syntax, you must specify the signal type in a static cast, as shown in this example:
    //connect(&process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, &Form::on_Process_Finished);
    connect(&process, static_cast<void(QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished), this, &Form::on_Process_Finished);
}


void Form::on_BtnExecutablePath_Clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open File");

    if (!fileName.isEmpty())
        lblExecutablePath->setText(fileName);
}

void Form::on_BtnRunProc1_Clicked()
{
    QProcess *process = new QProcess(this);
    QString program = lblExecutablePath->text();

    process->start(program);
}

void Form::on_BtnRunProc2_Clicked()
{
    QString program = lblExecutablePath->text();
    QStringList params = {editParam1->text(), editParam2->text()};
    QProcess *process = new QProcess(this);

    process->start(program, params);
    process->waitForFinished(-1);

    if (process->exitStatus() == QProcess::NormalExit)
        QMessageBox::information(this, "Information", QString("Return code is: %0").arg(process->exitCode()));
    else
        QMessageBox::critical(this, "Critical", "The process crashed!");
}

void Form::on_BtnRunProc3_Clicked()
{
    QString program = lblExecutablePath->text();
    QStringList params = {editParam1->text(), editParam2->text()};

    process.start(program, params);
}

void Form::on_BtnRunProc4_Clicked()
{
    QProcess process(this);
    QString program = lblExecutablePath->text();
    QStringList params = {editParam1->text(), editParam2->text()};

    process.start(program, params);

    if (!process.waitForStarted())
    {
        QMessageBox::critical(this, "Critical", "The process was not executed!");
        return;
    }

    process.write("3");
    process.closeWriteChannel();

    if (!process.waitForFinished())
    {
        QMessageBox::critical(this, "Critical", "The process was not executed!");
        return;
    }

    QByteArray result = process.readAll();

    QMessageBox::information(this, "Information", QString("Std-Out is: %0").arg(QString(result)));
    process.close();
}

void Form::on_BtnRunProc5_Clicked()
{
    QProcess process;
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    QString program = lblExecutablePath->text();

    env.insert("TMPDIR", "C:\\MyApp\\temp"); // Add an environment variable
    process.setProcessEnvironment(env);
    process.setProcessChannelMode(QProcess::MergedChannels);
    process.start(program);

    if (!process.waitForFinished())
        qDebug() << "Start failed:" << process.errorString();
    else
        qDebug() << "Start output:" << process.readAll();
}

void Form::on_BtnRunProc6_Clicked()
{
    QProcess process1;
    QProcess process2;

    process1.setStandardOutputProcess(&process2);
    process1.start("cmd /c dir");
    process1.waitForFinished(-1);

    process2.start("cmd /c sort");
    process2.waitForFinished(-1);

    qDebug() << process2.readAllStandardOutput();
}

void Form::on_Process_Finished(int exitCode, QProcess::ExitStatus exitStatus)
{
    if (exitStatus == QProcess::NormalExit)
        QMessageBox::information(this, "Information", QString("Return code is: %0").arg(exitCode));
    else
        QMessageBox::critical(this, "Critical", "The process crashed!");
}

