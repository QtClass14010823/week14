#ifndef GUI_TEST_H
#define GUI_TEST_H

#include <QObject>
#include <QTest>

class TestGui: public QObject
{
    Q_OBJECT

private slots:
    void testGui_data();
    void testGui();
};

#endif // GUI_TEST_H
