#include <gtk/gtk.h>

void button_clicked(GtkWidget *widget, gpointer data)
{
    g_print("\tButton Clicked - %d was passed.\n", data);
}

int main(int argc, char *argv[])
{
    gtk_init(&argc,&argv);
    
    GtkWidget *win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(win), "GTK+ Sample");
    gtk_window_set_default_size(GTK_WINDOW(win), 230, 150);
    gtk_window_set_position(GTK_WINDOW(win), GTK_WIN_POS_CENTER);
    g_signal_connect(win, "delete_event", gtk_main_quit, NULL);
    
    GtkWidget *btn = gtk_button_new_with_label("Button");
    gtk_widget_set_tooltip_text(btn, "Button widget");
    g_signal_connect(btn, "clicked", G_CALLBACK(button_clicked), (gpointer)10);
    GtkWidget *halign = gtk_alignment_new(0, 0, 0, 0);
    gtk_container_add(GTK_CONTAINER(halign), btn);
    gtk_container_add(GTK_CONTAINER(win), halign);
    gtk_widget_show_all(win);
    gtk_main();
    
    return 0;
}