#undef UNICODE
#include <windows.h>

const char g_szClassName[] = "myWindowcxlass";

// Step 4: the Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
	{
        case WM_CLOSE:
            DestroyWindow(hwnd);
        break;
        case WM_DESTROY:
            PostQuitMessage(0);
        break;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    WNDCLASSEX  wcx;
    HWND hwnd;
    MSG Msg;
    //Step 1: Registering the Window Class
    wcx.cbSize        = sizeof(WNDCLASSEX);
    wcx.style         = 0;
    wcx.lpfnWndProc   = WndProc;
    wcx.cbClsExtra    = 0;
    wcx.cbWndExtra    = 0;
    wcx.hInstance     = hInstance;
    wcx.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wcx.hCursor       = LoadCursor(NULL, IDC_ARROW);

	wcx.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcx.lpszMenuName  = NULL;
    wcx.lpszClassName = g_szClassName;
    wcx.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);
	
    if(!RegisterClassEx(&wcx))
	{
        MessageBox(NULL, "Window Registration Failed!", "Error!",
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }
	
    // Step 2: Creating the Window
    hwnd = CreateWindowEx(
							WS_EX_CLIENTEDGE,                  //DWORD dwExStyle
							g_szClassName,					   //LPCWSTR lpClassName
							"The title of my window",		   //LPCWSTR lpWindowName
							WS_OVERLAPPEDWINDOW,               //DWORD dwStyle
							CW_USEDEFAULT,                     //int X
							CW_USEDEFAULT,                     //int Y
							350,                               //int nWidth
							280,                               //int nHeight
							NULL,                              //HWND hWndParent
							NULL,                              //HMENU hMenu
							hInstance,                         //HINSTANCE hInstance
							NULL                               //LPVOID lpParam
	);
	
    if(hwnd == NULL)
	{
        MessageBox(NULL, "Window Creation Failed!", "Error!",
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }
	
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
	
    // Step 3: The Message Loop
    while(GetMessage(&Msg, NULL, 0, 0) > 0)
	{
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }
	
    return Msg.wParam;
} 
