#include <QCoreApplication>

#include <QFile>

void write()
{
    QFile file("D:\\Temp\\Qt\\Projects\\files\\file.dat");
    int array[3] = {31, 15, -8};

    if (!file.open(QIODevice::WriteOnly))
        return;

    for (int i = 0; i < sizeof(array) / sizeof(array[0]); i++)
    {
        file.write((char *)&array[i], sizeof(array[i]));
    }

    file.close();
}

void read()
{
    QFile file("D:\\Temp\\Qt\\Projects\\files\\file.dat");
    int no = 0;

    if (!file.open(QIODevice::ReadOnly))
        return;

    if (file.seek(sizeof(int)) && 2 * sizeof(int) <= file.size())
    {
        file.read((char *)&no, sizeof(int));
    }

    file.close();
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    write();
    read();

    return 0;
}
