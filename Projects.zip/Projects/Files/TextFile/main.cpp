#include <QCoreApplication>

#include <iostream>

#include <QFile>
#include <QTextStream>

using namespace std;

void read1()
{
    QFile file("D:\\Temp\\Qt\\Projects\\files\\TextFile\\Files\\rfile-linux.txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    while (!file.atEnd()) {
        QString line = file.readLine();

        cout << line.toStdString().c_str() << endl;
    }
}

void read2()
{
    QFile file("D:\\Temp\\Qt\\Projects\\files\\TextFile\\Files\\rfile-win.txt");
    QTextStream in(&file);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    while (!in.atEnd()) {
        QString line = in.readLine();

        cout << line.toStdString().c_str() << endl;
    }
}

void write1()
{
    QFile file("D:\\Temp\\Qt\\Projects\\files\\TextFile\\Files\\wfile-linux.txt");
    // QFile file("D:\\Temp\\Qt\\Projects\\files\\TextFile\\Files\\wfile-linux.txt");

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);
    out << "The number is: " << 130 << "\n";
    file.close();
}

void write2()
{
    QFile file("D:\\Temp\\Qt\\Projects\\files\\TextFile\\Files\\wfile-win.txt");

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);
    out << "The number is: " << 130 << "\n";
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //read1();
    read2();
    //write1();
    write2();

    return 0;
}
