#ifndef WORKER_H
#define WORKER_H

#include <QObject>

class Worker : public QObject
{
    Q_OBJECT
public:
    explicit Worker(QObject *parent = nullptr);
    ~Worker();
signals:
public slots:
    void doWork(QString strSrcFile, QString strDestFile);
    qint8 getPercentage();
    void pause();
    void resume();
    bool isFinished();
private:
    qint8 percentage;
    bool paused,resumed,finished;

};

#endif // WORKER_H
