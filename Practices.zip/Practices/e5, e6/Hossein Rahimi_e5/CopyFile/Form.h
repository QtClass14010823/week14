#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QThread>
#include <QString>
#include "worker.h"

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:
 void startWork(QString str1,QString str2);
 void startPause(bool cp_ps);

private slots:
    void onSrcClicked();
    void onDstClicked();
    void onCopyClicked();
    void onPauseClicked();
public slots:
 //   void doReturn(bool res );

private:
    QGridLayout *bLayout;
    QLabel *lblSrc, *lblDst;
    QLineEdit *lnEditSrc, *lnEditDst;
    QPushButton *btnSrcFile, *btnDstFile;
    QPushButton *btnCopy,*btnPause;
    QThread *workerThread;
    Worker *worker;

};

#endif // FORM_H
