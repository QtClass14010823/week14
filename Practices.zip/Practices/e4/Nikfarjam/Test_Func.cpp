#include "Test_Func.h"
#include"My_File.h"

extern My_File *FilePtr;

Test_Func::Test_Func(QObject *parent) : QObject(parent)
{

}
void Test_Func::Test_My_Func_Data()
{
  QTest::addColumn<QString>("FileName");
  QTest::addColumn<int>("WordCount");
  QTest::newRow("Case-1") << "//home//user//HW4//file1.txt" << 5 ;

}
void Test_Func::Test_My_Func()
{
    QFETCH(QString,FileName);
    QFETCH(int,WordCount);
    QCOMPARE(FilePtr->File_Analyse(FileName),WordCount);

}

