#include "My_File.h"

My_File::My_File(QWidget *parent)
    : QWidget(parent)
{

    MainGrid=new QGridLayout(this);
    MainGrid->addWidget(gbox(),0,0);
    this->setLayout(MainGrid);
    this->setWindowTitle("Home Work4");

    QRegularExpression rx(PATTERN);
    QValidator *validator = new QRegularExpressionValidator(rx, this);
    PathLnedit->setValidator(validator);
    PathLnedit->hasAcceptableInput();
    connect(PathLnedit,&QLineEdit::returnPressed,this,&My_File::My_Slot);
    connect(QuitBtn,&QPushButton::clicked,this,&My_File::close);

}

My_File::~My_File()
{
}

QGroupBox *My_File::gbox()
{
    QGroupBox *FileBox=new QGroupBox(tr("File info"));
    FileInfoLbl = new QLabel ("Total Word: ");
    PathLnedit =new QLineEdit ();
    Pathlbl =new QLabel("File Path: ");
    WordCtrLbl= new QLabel;

    QuitBtn =new QPushButton("Quit");
    QGridLayout *grl=new QGridLayout;
    grl->addWidget(Pathlbl,0,0);
    grl->addWidget(PathLnedit,0,1,1,6);
    grl->addWidget(FileInfoLbl,1,0);
    grl->addWidget(WordCtrLbl,1,1);
    grl->addWidget(QuitBtn,2,3);
    FileBox->setLayout(grl);
    return  FileBox;
}

int My_File::File_Analyse(QString Fname)
{
  int WordCtr=0;
   QFile file(Fname);

  if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
      return -1;
   while(!file.atEnd())
    {
        char ch;
        file.getChar(&ch);
        if(ch=='\n' || ch==' ')
            WordCtr++;
    }

  file.close();
  WordCtrLbl->setText(QString::number(WordCtr));
  return WordCtr;
}

void My_File::My_Slot()
{
    File_Analyse(PathLnedit->text());
}
