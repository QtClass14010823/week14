//
// Hossein Rahimi
//
#include <QApplication>
#include "Form.h"
//#include <QTest>
#include "uni_test.h"

#define TEST
Form *frm_ptr=nullptr;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;
    frm.show();
#ifdef TEST
    frm_ptr=&frm;
    Uni_Test test_func;
    QTest::qExec(&test_func ,argc,argv);
#endif
    return a.exec();
}


