#ifndef CIRQUEUE_H
#define CIRQUEUE_H

#include <QObject>
#include <QMutex>

class CirQueue : public QObject
{
    Q_OBJECT
public:
    explicit CirQueue(QObject *parent = nullptr);
    bool isFull();
    bool isEmpty();
    void add2queue(int element);
    int delFromQueue();

signals:
private:
    int items[100];
    int front,rear,SIZE;
    QMutex mutex;
};

#endif // CIRQUEUE_H
