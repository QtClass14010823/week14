#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include <QFile>
#include <QThread>
#include <QDebug>
#include <QSemaphore>



class Worker : public QObject
{
    Q_OBJECT
public:
    explicit Worker(QObject *parent = nullptr);
    ~Worker();
    QString name;
    void setParams(QString name,int min,int max);
public slots:
    void doWork();
private:
    QObject *parent;
    int min,max;
    bool isPrime(int n);
signals:

};

#endif // WORKER_H
