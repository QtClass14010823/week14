#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
signals:

private slots:
    void Run();
private:
    QGridLayout *bLayout;
    QPushButton *btnRun;
};

#endif // FORM_H
