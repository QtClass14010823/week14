#ifndef QDLG2_H
#define QDLG2_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QSpinBox>

class Qdlg2 : public QDialog
{
    Q_OBJECT
public:
    explicit Qdlg2(QWidget *parent = nullptr);
    int getHeight();

signals:
private slots:
    void on_btnNext_clicked();
    void on_btnBack_clicked();

private:
    QPushButton *btnNext,*btnBack;
    QPushButton *btnMan,*btnWomen;
    QSpinBox *spinBox;

    int height;

};

#endif // QDLG1_H
