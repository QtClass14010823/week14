<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fa_IR">
<context>
    <name>Qdlg1</name>
    <message>
        <source>Next</source>
        <translatorcomment>بعدی</translatorcomment>
        <translation>بعدی</translation>
    </message>
    <message>
        <source>Back</source>
        <translatorcomment>قبلی</translatorcomment>
        <translation>قبلی</translation>
    </message>
    <message>
        <source>Select Your Gender :</source>
        <translation>انتخاب جنسیت :</translation>
    </message>
</context>
<context>
    <name>Qdlg2</name>
    <message>
        <source>Next</source>
        <translation>بعدی</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>قبلی</translation>
    </message>
    <message>
        <source>Enter Your Height :</source>
        <translation>قد شما :</translation>
    </message>
</context>
<context>
    <name>Qdlg3</name>
    <message>
        <source>Next</source>
        <translatorcomment>بعدی</translatorcomment>
        <translation>بعدی</translation>
    </message>
    <message>
        <source>Back</source>
        <translatorcomment>قبلی</translatorcomment>
        <translation>قبلی</translation>
    </message>
    <message>
        <source>Enter Your Weight :</source>
        <translation>وزن شما :</translation>
    </message>
</context>
<context>
    <name>Qdlg4</name>
    <message>
        <source>Next</source>
        <translation>بعدی</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>قبلی</translation>
    </message>
    <message>
        <source>Enter Your Age :</source>
        <translation>سن شما :</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <source>BMI Calculator</source>
        <translation type="vanished">محاسبه شاخص توده بدنی</translation>
    </message>
    <message>
        <source>BMI: %1</source>
        <translation type="vanished">شاخص توده بدنی: </translation>
    </message>
    <message>
        <source>Your BMI: %1</source>
        <translation>شاخص توده بدنی شما: %1</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>شروع</translation>
    </message>
    <message>
        <source>BMI &amp; BMR Calculator</source>
        <translation>محاسبه شاخص توده بدنی و اندازه متابولیسم پایه</translation>
    </message>
    <message>
        <source>Your BMR: %1</source>
        <translation type="obsolete">متابولیسم پایه شما: %1</translation>
    </message>
    <message>
        <source>Your BMR: %1 Kcal</source>
        <translation>متابولیسم پایه شما: %1 Kcal</translation>
    </message>
    <message>
        <source>Your BMR: %1 Kkal</source>
        <translation>متابولیسم پایه شما: %1 Kcal</translation>
    </message>
</context>
</TS>
