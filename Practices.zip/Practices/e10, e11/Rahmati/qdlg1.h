#ifndef QDLG1_H
#define QDLG1_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>

class Qdlg1 : public QDialog
{
    Q_OBJECT
public:
    explicit Qdlg1(QWidget *parent = nullptr);
    int getGender();

signals:
private slots:
    void on_btnNext_clicked();
    void on_btnBack_clicked();
    void on_btnMan_clicked();
    void on_btnWomen_clicked();

private:
    QPushButton *btnNext,*btnBack;
    QPushButton *btnMan,*btnWomen;
    int gender;

};

#endif // QDLG1_H
