#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{


    btm1=new QPushButton("SWAP");
    btm2=new QPushButton("EXIT");
    lbl1=new QLabel("Value1 :");
    lbl2=new QLabel("Value2 :");
    lnEdt1= new QLineEdit ();
    lnEdt2= new QLineEdit ();

    mainGride = new QGridLayout;
    mainWidget=new QWidget;
    setCentralWidget(mainWidget);
    mainWidget->setLayout(mainGride);

    mainGride->addWidget(lbl1,0,0);
    mainGride->addWidget(lbl2,2,0);
    mainGride->addWidget(lnEdt1,0,1);
    mainGride->addWidget(lnEdt2,2,1);
    mainGride->addWidget(btm1,0,2);
    mainGride->addWidget(btm2,2,2);

    connect(btm2,SIGNAL(clicked(bool)),this,SLOT(close()));
    connect(btm1,SIGNAL(clicked(bool)),this,SLOT(swapSlot()));
}

MainWindow::~MainWindow()
{
}

void MainWindow::swapSlot()
{
    tmpStr =lnEdt1->text();
    lnEdt1->setText(lnEdt2->text());
    lnEdt2->setText(tmpStr);
}
