#ifndef TELL_BOOK_H
#define TELL_BOOK_H

#include <QMainWindow>
#include<QLabel>
#include<QPushButton>
#include<QLineEdit>
#include<QGridLayout>
#include<QGroupBox>
#include<QMessageBox>
#include<QTextStream>
#include<QFile>
#include<stdio.h>

class Tell_Book : public QMainWindow
{
    Q_OBJECT

private:
    QLabel *lbl1;
    QLabel *lbl2;
    QLabel *lbl3;
    QLabel *lbl4;
    QLabel *lbl5;
    QLineEdit *lnEdt1;
    QLineEdit *lnEdt2;
    QLineEdit *lnEdt3;
    QPushButton *btn1;
    QPushButton *btn2;
    QGroupBox *gbox1();
    QGroupBox *gbox2();
    QGroupBox *gbox3();
    QWidget *mainWidget;
    QGridLayout *mainGride;
    QString tmpStr;
    QMessageBox *msg;
    int counter=0;

    struct contact_info
    {
        char name[20];
        int tell;
    };

public:
    Tell_Book(QWidget *parent = nullptr);
    ~Tell_Book();
public slots:
   void Add_Func();
   void Find_Func();


};
#endif // TELL_BOOK_H
