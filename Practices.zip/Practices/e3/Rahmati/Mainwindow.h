#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QGroupBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QWidget *window=new QWidget(this);
    QVBoxLayout *vl=new QVBoxLayout(window);
    QGroupBox *gbInfo=new QGroupBox(window);
    QGroupBox *gbAdd=new QGroupBox(window);
    QGroupBox *gbFind=new QGroupBox(window);
    QLabel *lblCount=new QLabel(gbInfo);
    QLabel *lblName=new QLabel(gbAdd);
    QLabel *lblTel=new QLabel(gbAdd);
    QLabel *lblFind=new QLabel(gbFind);
    QLineEdit *leName=new QLineEdit(gbAdd);
    QLineEdit *leTel=new QLineEdit(gbAdd);
    QLineEdit *leFind=new QLineEdit(gbFind);

    void get_total_contact();
    void btnAdd_clicked();
    void find_contact();


};

struct Contact{
    char name[20];
    int tel;
};


#endif // MAINWINDOW_H
