#ifndef COPYFILETHREAD_H
#define COPYFILETHREAD_H

#include <QThread>
#include <QMutex>
#include <QObject>

class CopyFileThread : public QThread
{
    Q_OBJECT

public:
    CopyFileThread(QObject *parent = nullptr);
    void setParams(QString srcFile, QString dstFile);
    void toggleExecutionState(bool isSuspended);

protected:
    void run() Q_DECL_OVERRIDE;

signals:
    void progressChanged(int percent);

private:
    QString srcFile;
    QString dstFile;
    bool isSuspended;
    QMutex mutex;
};

#endif // COPYFILETHREAD_H
