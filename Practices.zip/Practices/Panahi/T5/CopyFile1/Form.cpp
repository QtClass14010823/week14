#include "Form.h"

#include <QFile>
#include <QFileDialog>
#include <QMessageBox>

Form::Form(QWidget *parent) :
    QWidget(parent), thread(this)
{
    gLayout = new QGridLayout(this);
    lblSrc = new QLabel("Source File:", this);
    lblDst = new QLabel("Destination File:", this);
    lnEditSrc = new QLineEdit(this);
    lnEditDst = new QLineEdit(this);
    btnSrcFile = new QPushButton("...", this);
    btnDstFile = new QPushButton("...", this);

    hLayout = new QHBoxLayout(this);
    btnCopy = new QPushButton("Copy", this);
    btnPause = new QPushButton("Pause", this);
    btnResume = new QPushButton("Resume", this);

    hLayout->addWidget(btnCopy);
    hLayout->addWidget(btnPause);
    hLayout->addWidget(btnResume);

    gLayout->addWidget(lblSrc, 0, 0);
    gLayout->addWidget(lblDst, 1, 0);
    gLayout->addWidget(lnEditSrc, 0, 1);
    gLayout->addWidget(lnEditDst, 1, 1);
    gLayout->addWidget(btnSrcFile, 0, 2);
    gLayout->addWidget(btnDstFile, 1, 2);
    gLayout->addLayout(hLayout, 2, 0, 1, 3);
    this->setLayout(gLayout);

    this->setWindowTitle("Copy File");
    connect(btnSrcFile, &QPushButton::clicked, this, &Form::onSrcClicked);
    connect(btnDstFile, &QPushButton::clicked, this, &Form::onDstClicked);
    connect(btnCopy, &QPushButton::clicked, this, &Form::onCopyClicked);
    connect(btnPause, &QPushButton::clicked, this, &Form::onPauseClicked);
    connect(btnResume, &QPushButton::clicked, this, &Form::onResumeClicked);
    connect(&thread, &CopyFileThread::progressChanged, this, &Form::on_Thread_ProgressChanged);
    connect(&thread, &CopyFileThread::finished, this, &Form::on_Thread_Finished);
}

void Form::onSrcClicked()
{
    QString file1Name = QFileDialog::getOpenFileName(this,
             "Select source file", "/home", tr("All Files (*.*)"));

    lnEditSrc->setText(file1Name);
}

void Form::onDstClicked()
{
    QString file1Name = QFileDialog::getSaveFileName(this,
             "Select destination file", "/home", tr("All Files (*.*)"));

    lnEditDst->setText(file1Name);
}

void Form::onCopyClicked()
{
    if (thread.isRunning())
        return;

    thread.setParams(lnEditSrc->text(), lnEditDst->text());
    thread.start();
}

void Form::onPauseClicked()
{
    thread.toggleExecutionState(true);
}

void Form::onResumeClicked()
{
    thread.toggleExecutionState(false);
}

void Form::on_Thread_ProgressChanged(int percent)
{
    this->setWindowTitle(QString("Copying %0%1").arg(percent).arg("%"));
}

void Form::on_Thread_Finished()
{
    this->setWindowTitle("Copy File");
    QMessageBox::information(this, "Information", "Copy completed.");
}
