#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

#include "CopyFileThread.h"

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private slots:
    void onSrcClicked();
    void onDstClicked();
    void onCopyClicked();
    void onPauseClicked();
    void onResumeClicked();
    void on_Thread_ProgressChanged(int percent);
    void on_Thread_Finished();

private:
    QGridLayout *gLayout;
    QHBoxLayout *hLayout;
    QLabel *lblSrc, *lblDst;
    QLineEdit *lnEditSrc, *lnEditDst;
    QPushButton *btnSrcFile, *btnDstFile;
    QPushButton *btnCopy, *btnPause, *btnResume;
    CopyFileThread thread;
};

#endif // FORM_H
