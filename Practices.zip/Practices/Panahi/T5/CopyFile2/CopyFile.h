#ifndef COPYFILE_H
#define COPYFILE_H

#include <QObject>
#include <QMutex>

class CopyFile : public QObject
{
    Q_OBJECT

public:
    CopyFile(QObject *parent = nullptr);
    void toggleExecutionState(bool isSuspended);

signals:
    void progressChanged(int percent);
    void copyFinished();

public slots:
    void startCopy(QString srcFile, QString dstFile);

private:
    QString srcFile;
    QString dstFile;
    bool isSuspended;
    bool startCopyIsRunning;
    QMutex mutex;
};

#endif // COPYFILE_H
