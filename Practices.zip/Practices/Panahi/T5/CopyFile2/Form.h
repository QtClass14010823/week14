#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QThread>

#include "CopyFile.h"

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onSrcClicked();
    void onDstClicked();
    void onCopyClicked();
    void onPauseClicked();
    void onResumeClicked();
    void on_CopyFile_ProgressChanged(int percent);
    void on_CopyFile_Finished();

private:
    QGridLayout *gLayout;
    QHBoxLayout *hLayout;
    QLabel *lblSrc, *lblDst;
    QLineEdit *lnEditSrc, *lnEditDst;
    QPushButton *btnSrcFile, *btnDstFile;
    QPushButton *btnCopy, *btnPause, *btnResume;
    QThread *copyFileThread;
    CopyFile *copyFile;
};

#endif // FORM_H
