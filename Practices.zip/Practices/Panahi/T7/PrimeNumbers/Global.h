#ifndef GLOBAL_H
#define GLOBAL_H

#define BUFFER_SIZE     50
#define MAX_FILE_NUMBER 3
#define THREAD_NUMBER   10

#endif // GLOBAL_H
