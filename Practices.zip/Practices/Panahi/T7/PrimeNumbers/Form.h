#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

#include "PrimeNumbersThread.h"
#include "Global.h"

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private slots:
    void onStartClicked();
    void onResourceUpdated(int instance, bool isOccupied);

private:
    PrimeNumbersThread thread[THREAD_NUMBER];
    QGridLayout gLayout;
    QLabel lblThreadText[THREAD_NUMBER];
    QLabel lblThreadStatus[THREAD_NUMBER];
    QPushButton btnStart;
    int NumberInCA;
};

#endif // FORM_H
