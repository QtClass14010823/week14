#include <QApplication>

#include "Form.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form form;
    QStringList args = a.arguments();

    form.initForm(&args);
    form.show();

    return a.exec();
}
