#ifndef GLOBAL_H
#define GLOBAL_H

#define QUEUE_SIZE  100

#endif // GLOBAL_H
