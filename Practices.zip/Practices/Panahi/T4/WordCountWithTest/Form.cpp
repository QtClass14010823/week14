#include "Form.h"

#include <QFile>
#include <QMessageBox>
#include <QTextStream>

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f),
    regExpValidator(this)
{
    this->setObjectName(QString::fromUtf8("Form"));

    vLayout = new QVBoxLayout(this);
    gLayout = new QGridLayout(this);
    lblFilePath = new QLabel("File Path:", this);
    textFilePath = new QLineEdit(this);
    lblWordCountTitle = new QLabel("Word Count:", this);
    lblWordCountValue = new QLabel("0", this);
    hLayout = new QHBoxLayout(this);
    horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    btnQuit = new QPushButton("Quit", this);

    lblWordCountValue->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
    textFilePath->setObjectName(QString::fromUtf8("textFilePath"));

    // ^(?:[\w]\:|\\)(\\[a-z_\-\s0-9\.]+)+\.(txt|gif|pdf|doc|docx|xls|xlsx)$

    // Matches
    // \\192.168.0.1\folder\file.pdf
    // \\192.168.0.1\my folder\folder.2\file.gif
    // c:\my folder\abc abc.docx
    // c:\my-folder\another_folder\abc.v2.docx

    // Non-Matches
    // \\192.168.0.1\folder\fi<le.pdf
    // \\192.168.0.1\folder\\file.pdf
    // \\192.168.0.1\my folder\folder.2\.gif
    // c:\my folder\another_folder\.docx
    // c:\my folder\\another_folder\abc.docx
    // c:\my folder\another_folder\ab*c.v2.docx
    // c:\my?folder\another_folder\abc.v2.docx
    // file.xls

#ifdef Q_OS_WIN
     regExpValidator.setRegularExpression(QRegularExpression("^(\\w:|\\\\)(\\\\[a-zA-Z_\\s0-9]+)+"));
#elif defined (Q_OS_UNIX)
    regExpValidator.setRegularExpression(QRegularExpression("(/[a-zA-Z_\\s0-9]+)+"));
#endif

    textFilePath->setValidator(&regExpValidator);
    gLayout->addWidget(lblFilePath, 0, 0);
    gLayout->addWidget(textFilePath, 0, 1);
    gLayout->addWidget(lblWordCountTitle, 1, 0);
    gLayout->addWidget(lblWordCountValue, 1, 1);

    hLayout->addItem(horizontalSpacer);
    btnQuit->setObjectName(QString::fromUtf8("btnQuit"));
    hLayout->addWidget(btnQuit);

    vLayout->addLayout(gLayout);
    vLayout->addLayout(hLayout);

    this->setLayout(vLayout);

    //connect(btnQuit, &QPushButton::clicked, this, &Form::on_btnQuit_Clicked);
    QMetaObject::connectSlotsByName(this);
}

void Form::on_textFilePath_returnPressed()
{
    int count = wordCount(textFilePath->text());

    if (count >= 0)
        lblWordCountValue->setText(QString::number(count));
    else
        lblWordCountValue->setText("0");
}

void Form::on_btnQuit_clicked()
{
    close();
}

int Form::wordCount(const QString filePath)
{
    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return -1;

    QTextStream textStream(&file);
    int count = 0;

    while (!textStream.atEnd()) {
        const QStringList words =  textStream.readLine().split(' ');
        count += words.count();
    }

    file.close();

    return count;
}
