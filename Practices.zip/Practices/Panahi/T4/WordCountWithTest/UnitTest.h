#ifndef UNITTEST_H
#define UNITTEST_H

#include <QObject>
#include <QTest>

class UnitTest : public QObject
{
    Q_OBJECT

public:
    explicit UnitTest(QObject *parent = nullptr);

signals:

private slots:
    void wordCount_data();
    void wordCount();
};

#endif // UNITTEST_H
