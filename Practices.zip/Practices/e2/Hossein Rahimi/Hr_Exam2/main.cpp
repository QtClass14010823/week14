//
// Hossein Rahimi
// Program No:2
//
#include <QApplication>
#include <QtWidgets>
#include<QLabel>
#include<QLineEdit>
#include<QPushButton>
#include <QTextStream>

int main(int argc, char *argv[])
{
    {
        QApplication app(argc, argv);
        QWidget w;
        w.setFixedSize(250,80+(argc-1)*20);
        QLabel label[argc-1],lb1(&w);
        lb1.setText("Parameters Count : "+QString::number(argc-1));
        lb1.move(10,10);
        QLineEdit edit[argc-1];
        QPushButton btn1("Exit",&w);
        btn1.move(140,30+argc*20);
//        QTextStream(stdout) << "Par_No="<<argc << endl;
        for(int i=0;i<(argc-1);i++)
        {
           label[i].setParent(&w);
           label[i].setText("Parameter "+QString::number(i+1)+" :");
           label[i].move(10,40+i*20);

           edit[i].setParent(&w);
           edit[i].setText(argv[i+1]);
           edit[i].move(100,40+i*20);
           edit[i].setEnabled(false);
        }

        w.show();
        QObject::connect(&btn1,&QPushButton::clicked,&app, &QApplication::quit);
        return app.exec();
    }
}
