#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget window;
    window.setWindowTitle("Second");

    QString strLabel="Parameters Count: ";

    QLabel lblPc(strLabel, &window);
    QLabel lblP1("Parameter 1:", &window);
    QLabel lblP2("Parameter 2:", &window);
    QLabel lblP3("Parameter 3:", &window);

    lblPc.move(20, 40);
    lblP1.move(20, 80);
    lblP2.move(20, 120);
    lblP3.move(20, 160);




    QLineEdit le1(&window);
    QLineEdit le2(&window);
    QLineEdit le3(&window);
    le1.setReadOnly(true);
    le2.setReadOnly(true);
    le3.setReadOnly(true);

    le1.move(120,80);
    le2.move(120,120);
    le3.move(120,160);

    if(argc<2)  return 0;
    if(argc>=2)
    {
        lblPc.setText(strLabel+QString::number(argc-1));
        le1.setText(argv[1]);
    }
    if(argc>=3)  le2.setText(argv[2]);
    if(argc>=4)  le3.setText(argv[3]);

    QPushButton btnExit("Exit",&window);

    btnExit.move(170,220);

    QObject::connect(&btnExit, &QPushButton::clicked, &a,&QApplication::quit);

    window.show();

    return a.exec();
}
