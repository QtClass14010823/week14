#ifndef WGT1_H
#define WGT1_H

#include <QWidget>

class Wgt1 : public QWidget
{
    Q_OBJECT
public:
    explicit Wgt1(QWidget *parent = nullptr);

signals:

};

#endif // WGT1_H
