#include "Form.h"

#include <QGridLayout>
#include <QPushButton>
#include <QStackedWidget>

#include "Wgt1.h"
#include "Wgt2.h"

Form::Form(QWidget *parent) : QWidget(parent)
{
    mainLayout = new QGridLayout(this);
    stkWgt = new QStackedWidget;
    next = new QPushButton("Next");
    back = new QPushButton("Back");

    mainLayout->addWidget(stkWgt, 0, 0, 1, 2);
    mainLayout->addWidget(back, 1, 0);
    mainLayout->addWidget(next, 1, 1);

    stkWgt->addWidget(new Wgt1);
    stkWgt->addWidget(new Wgt2);

    stkWgt->setCurrentIndex(0);
}
