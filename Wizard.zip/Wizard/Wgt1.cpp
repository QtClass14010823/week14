#include "Wgt1.h"

#include <QLineEdit>

Wgt1::Wgt1(QWidget *parent) : QWidget(parent)
{
    new QLineEdit(this);
}
