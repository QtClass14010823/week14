#include "Wgt2.h"

#include <QSpinBox>

Wgt2::Wgt2(QWidget *parent) : QWidget(parent)
{
    new QSpinBox(this);
}
