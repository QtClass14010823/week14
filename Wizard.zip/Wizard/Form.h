#ifndef FORM_H
#define FORM_H

#include <QWidget>

QT_BEGIN_NAMESPACE
class QPushButton;
class QGridLayout;
class QStackedWidget;
QT_END_NAMESPACE

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private:
    QPushButton *next;
    QStackedWidget *stkWgt;
    QPushButton *back;
    QGridLayout *mainLayout;
};

#endif // FORM_H
