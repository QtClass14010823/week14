#ifndef WGT2_H
#define WGT2_H

#include <QWidget>

class Wgt2 : public QWidget
{
    Q_OBJECT
public:
    explicit Wgt2(QWidget *parent = nullptr);

signals:

};

#endif // WGT2_H
